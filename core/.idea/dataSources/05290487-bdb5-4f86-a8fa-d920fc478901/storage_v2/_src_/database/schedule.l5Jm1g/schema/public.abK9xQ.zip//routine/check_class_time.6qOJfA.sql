create function check_class_time()
  returns trigger
language plpgsql
as $$
DECLARE
	cur_starts_at time;
	cur_ends_at time;
	cur_id integer;
BEGIN
	cur_id = NEW.class_time_id;

	IF (TG_OP = 'INSERT') OR (NEW.starts_at IS DISTINCT FROM OLD.starts_at) THEN
		cur_starts_at = NEW.starts_at;
	ELSE
		cur_starts_at = OLD.starts_at;
	END IF;

	IF (TG_OP = 'INSERT') OR (NEW.ends_at IS DISTINCT FROM OLD.ends_at) THEN
		cur_ends_at = NEW.ends_at;
	ELSE
		cur_ends_at = OLD.ends_at;
	END IF;

	IF NOT(is_class_time_valid(cur_id, cur_starts_at, cur_ends_at)) THEN
	   RAISE EXCEPTION 'Занятие не может пересекаться с другими занятиями по времени.';
	   ROLLBACK;
	END IF;
	RETURN NEW;
END;
$$;

