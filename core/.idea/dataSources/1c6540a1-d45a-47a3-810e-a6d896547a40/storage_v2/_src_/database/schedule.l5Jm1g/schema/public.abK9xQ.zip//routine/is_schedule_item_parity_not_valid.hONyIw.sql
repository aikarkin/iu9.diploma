create function is_schedule_item_parity_not_valid(_item_parity_id integer)
  returns boolean
language plpgsql
as $$
DECLARE
	cur_time_of_class time_of_classes%rowtype;
BEGIN
    SELECT * FROM time_of_classes 
        INTO cur_time_of_class
        WHERE schedule_item_parity_id = _item_parity_id;
    RETURN
        (EXISTS
            (SELECT * FROM time_of_classes
            WHERE 
                (cur_time_of_class.schedule_item_parity_id != _item_parity_id)
            AND
                (cur_time_of_class.subject_id != subject_id OR cur_time_of_class.class_type_id != class_type_id)
            AND
                (cur_time_of_class.classroom_id = classroom_id)
            AND
                (cur_time_of_class.day_of_weak = day_of_weak)
            AND 
                (cur_time_of_class.day_parity = day_parity)
            AND 
                (cur_time_of_class.class_time_id = class_time_id)
            )
        );
END
$$;

