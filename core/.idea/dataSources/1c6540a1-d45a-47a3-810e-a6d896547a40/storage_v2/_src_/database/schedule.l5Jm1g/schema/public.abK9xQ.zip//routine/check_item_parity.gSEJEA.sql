create function check_item_parity()
  returns trigger
language plpgsql
as $$
BEGIN
    IF is_schedule_item_parity_not_valid(NEW) THEN
        RAISE EXCEPTION 
            'Данной занятие не может проходить в аудитории c room_id="%", так как в этой аудитории в указанное время уже проходит другое занятие.',
            NEW.classroom_id;
        ROLLBACK;
    END IF;
    RETURN NEW;
END;
$$;

