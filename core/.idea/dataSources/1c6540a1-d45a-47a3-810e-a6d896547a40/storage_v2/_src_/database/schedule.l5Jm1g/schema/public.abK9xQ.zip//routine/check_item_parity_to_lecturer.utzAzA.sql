create function check_item_parity_to_lecturer()
  returns trigger
language plpgsql
as $$
BEGIN
    IF is_lecturer_class_not_valid(NEW) THEN
        RAISE EXCEPTION 'У преподователя с lecturer_id="" уже есть занятие в данное время.';
        ROLLBACK;
    END IF;
    RETURN NEW;
END;
$$;

