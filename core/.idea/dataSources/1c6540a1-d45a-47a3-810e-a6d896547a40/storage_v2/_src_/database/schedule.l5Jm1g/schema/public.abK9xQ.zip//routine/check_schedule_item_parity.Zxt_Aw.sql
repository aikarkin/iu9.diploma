create function check_schedule_item_parity()
  returns trigger
language plpgsql
as $$
DECLARE
    r schedule_item_parity%rowtype;
BEGIN

    FOR r IN (SELECT * FROM schedule_item_parity WHERE schedule_item_id = NEW.schedule_item_id)
    LOOP
        IF (
                ((NEW.day_parity = 'ЧС/ЗН') AND (r.day_parity = 'ЧС' OR r.day_parity = 'ЗН'))
                    OR
                ((NEW.day_parity = 'ЧС' OR NEW.day_parity = 'ЗН') AND (r.day_parity = 'ЧС/ЗН'))
           )
        THEN
            RAISE EXCEPTION
                'Невозможно присвоить данному занятию значение "%", т. к. для него уже указано занчение "%".',
                NEW.day_parity,
                r.day_parity;
            ROLLBACK;
        END IF;
    END LOOP;
    RETURN NEW;
END;
$$;

